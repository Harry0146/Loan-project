// Loan Application Form Submission
const loanForm = document.getElementById('loanForm');
if (loanForm) {
    loanForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const stateID = loanForm.stateID.files[0];
        if (!stateID) {
            alert("State ID is required!");
            return;
        }
        if (stateID.size > 2 * 1024 * 1024) { // 2MB limit
            alert("File size must be less than 2MB.");
            return;
        }
        alert("Application submitted successfully! (Frontend only)");
        loanForm.reset();
    });
}

// Loan Calculator
const calcForm = document.getElementById('calcForm');
if (calcForm) {
    calcForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const amount = parseFloat(document.getElementById('calcAmount').value);
        const rate = parseFloat(document.getElementById('calcRate').value) / 100 / 12;
        const term = parseInt(document.getElementById('calcTerm').value);

        const monthlyPayment = (amount * rate) / (1 - Math.pow(1 + rate, -term));
        document.getElementById('calcResult').innerText =
            `Estimated Monthly Payment: $${monthlyPayment.toFixed(2)}`;
    });
}
