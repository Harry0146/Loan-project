const express = require('express');
const app = express();

// Middleware to handle JSON
app.use(express.json());

// Basic route
app.get('/', (req, res) => {
  res.send('Loan website backend is running 🚀');
});

// Start server
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
